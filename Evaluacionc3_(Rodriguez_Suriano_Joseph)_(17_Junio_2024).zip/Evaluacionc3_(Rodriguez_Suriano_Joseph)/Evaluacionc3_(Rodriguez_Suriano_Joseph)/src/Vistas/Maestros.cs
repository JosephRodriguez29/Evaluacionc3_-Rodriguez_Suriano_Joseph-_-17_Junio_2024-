﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Evaluacionc3__Rodriguez_Suriano_Joseph_.src.Vistas
{
    public partial class Maestros : Form
    {
        public Maestros()
        {
            InitializeComponent();
        }

        private void Maestros_Load(object sender, EventArgs e)
        {
            actualizarDatos();

        }

        public void actualizarDatos()
        {
            // TODO: This line of code loads data into the 'universidadDataSet.tb_Maestro' table. You can move, or remove it, as needed.
            this.tb_MaestroTableAdapter1.Fill(this.universidadDataSet.tb_Maestro);
            // TODO: This line of code loads data into the 'identidadesMaestro.tb_Maestro' table. You can move, or remove it, as needed.
            this.tb_MaestroTableAdapter.Fill(this.identidadesMaestro.tb_Maestro);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO tb_Maestro (nombre,ap_paterno,ap_materno,matricula_empleado,fecha_ingreso,email,telefono) VALUES (@nombre,@ap_paterno,@ap_materno,@matricula_empleado,@fecha_ingreso,@email,@telefono)";
            SqlCommand comando = new SqlCommand(query,Conexion.getInstance().getConexion());
            comando.Parameters.AddWithValue("@nombre", textBox1.Text);
            comando.Parameters.AddWithValue("@ap_paterno", textBox2.Text);
            comando.Parameters.AddWithValue("@ap_materno", textBox3.Text);
            comando.Parameters.AddWithValue("@matricula_empleado", textBox4.Text);
            comando.Parameters.AddWithValue("@fecha_ingreso", dateTimePicker1.Value);
            comando.Parameters.AddWithValue("@email", textBox5.Text);
            comando.Parameters.AddWithValue("@telefono", textBox6.Text);

            try
            {
                comando.ExecuteNonQuery();
                MessageBox.Show("Maestro Agregado Correctamente");
                actualizarDatos();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "UPDATE tb_Maestro SET nombre=@nombre,ap_paterno=@ap_paterno,ap_materno=@ap_materno,matricula_empleado=@matricula_empleado,fecha_ingreso=@fecha_ingreso,email=@email,telefono=@telefono WHERE pk_Maestro = @pk_Maestro";
            SqlCommand comando = new SqlCommand(query, Conexion.getInstance().getConexion());
            comando.Parameters.AddWithValue("@pk_Maestro", comboBox1.SelectedIndex);
            comando.Parameters.AddWithValue("@nombre", textBox1.Text);
            comando.Parameters.AddWithValue("@ap_paterno", textBox2.Text);
            comando.Parameters.AddWithValue("@ap_materno", textBox3.Text);
            comando.Parameters.AddWithValue("@matricula_empleado", textBox4.Text);
            comando.Parameters.AddWithValue("@fecha_ingreso", dateTimePicker1.Value);
            comando.Parameters.AddWithValue("@email", textBox5.Text);
            comando.Parameters.AddWithValue("@telefono", textBox6.Text);

            try
            {
                comando.ExecuteNonQuery();
                MessageBox.Show("Maestro Agregado Correctamente");
                actualizarDatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
